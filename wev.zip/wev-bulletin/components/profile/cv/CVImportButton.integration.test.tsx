import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import CVImportButton from './CVImportButton';
import { NextIntlClientProvider } from 'next-intl';
import notify from '@/lib/toast';

// Mock translations
const messages = {
  profile: {
    cvImportInputLabel: 'Upload CV file',
    cvImportButton: 'Import from CV',
    cvReimportButton: 'Update from CV',
    cvImportDropHint: 'or drag and drop PDF/DOCX',
    cvReimportWarning: 'This will overwrite your current skills and values.',
    cvImportedIndicator: 'Last imported: {fileName} on {importedAt}',
    cvUploadStartingWarning: 'Uploading your CV...',
    cvParsingWaitWarning: 'Parsing your CV, please wait...',
    cvReviewingExperienceWarning: 'Reviewing your experience...',
    cvDeterminingSkillsWarning: 'Determining your skills and values...',
    cvParsingStillWorkingWarning:
      'Still working on your CV... This can take up to a minute. Please remain on this page while it finishes.',
    cv_import_failed: 'CV import failed. Please try another file.',
    rate_limit_exceeded:
      "You've reached the CV import limit. Please wait a bit before trying again.",
    unsupported_file_type: 'Only PDF and DOCX files are supported.',
    empty_file: 'The selected file is empty.',
  },
};

function renderWithIntl(ui: React.ReactElement) {
  return render(
    <NextIntlClientProvider locale="en" messages={messages}>
      {ui}
    </NextIntlClientProvider>,
  );
}

describe('CVImportButton', () => {
  let globalFetchMock: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    globalFetchMock = vi.fn();
    vi.stubGlobal('fetch', globalFetchMock);
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('renders the import button and hidden file input', () => {
    renderWithIntl(
      <CVImportButton locale="en" cvImport={null} isSaving={false} onConfirmImport={() => {}} />,
    );

    expect(screen.getByRole('button', { name: 'Import from CV' })).toBeVisible();
    expect(document.querySelector('input[type="file"]')).toBeInTheDocument();
  });

  it('calls the API and fires onConfirmImport when a file is selected', async () => {
    const user = userEvent.setup();
    const handleConfirmImport = vi.fn().mockResolvedValue(undefined);

    globalFetchMock.mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        skills: [
          {
            uri: 'test-uri',
            preferredLabel: { en: 'Test Skill', fr: 'Compétence Test' },
            skillType: 'skill',
            reuseLevel: 'cross-sector',
          },
        ],
        values: ['Innovation'],
        warnings: [],
        metadata: {
          filename: 'test.pdf',
          imported_at: '2023-10-01T12:00:00Z',
          source: 'cv_upload',
          locale: 'en',
        },
      }),
    });

    renderWithIntl(
      <CVImportButton
        locale="en"
        cvImport={null}
        isSaving={false}
        onConfirmImport={handleConfirmImport}
      />,
    );

    const file = new File(['dummy content'], 'test.pdf', { type: 'application/pdf' });

    // We get the input via querySelector since it is hidden and might not have a label that userEvent easily finds
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;

    // Simulate user selecting a file
    await user.upload(input, file);

    await waitFor(() => {
      expect(handleConfirmImport).toHaveBeenCalledWith({
        skills: [
          {
            uri: 'test-uri',
            preferredLabel: { en: 'Test Skill', fr: 'Compétence Test' },
            skillType: 'skill',
            reuseLevel: 'cross-sector',
          },
        ],
        values: ['Innovation'],
        warnings: [],
        cvImport: {
          filename: 'test.pdf',
          imported_at: '2023-10-01T12:00:00Z',
          source: 'cv_upload',
          locale: 'en',
        },
      });
    });
  });

  it('shows re-import text and warning if cvImport metadata is present', () => {
    renderWithIntl(
      <CVImportButton
        locale="en"
        cvImport={{
          filename: 'old.pdf',
          imported_at: '2023-10-01T12:00:00Z',
          source: 'cv_upload',
          locale: 'en',
        }}
        isSaving={false}
        onConfirmImport={() => {}}
      />,
    );

    expect(screen.getByRole('button', { name: 'Update from CV' })).toBeVisible();
    // Warning is always visible when a previous import exists (not just on drag)
    expect(screen.getByText(/This will overwrite your current skills and values/)).toBeVisible();
  });

  it('falls back to a generic message for unknown server error strings', async () => {
    const user = userEvent.setup();

    globalFetchMock.mockResolvedValueOnce({
      ok: false,
      status: 500,
      json: async () => ({
        error: 'upstream_service_meltdown',
      }),
    });

    renderWithIntl(
      <CVImportButton locale="en" cvImport={null} isSaving={false} onConfirmImport={() => {}} />,
    );

    const file = new File(['dummy content'], 'test.pdf', { type: 'application/pdf' });
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;

    await user.upload(input, file);

    await waitFor(() => {
      expect(notify.error).toHaveBeenCalledWith('CV import failed. Please try another file.');
    });
  });

  it('shows the translated rate limit message when the API returns a stable code', async () => {
    const user = userEvent.setup();

    globalFetchMock.mockResolvedValueOnce({
      ok: false,
      status: 429,
      json: async () => ({
        error: 'rate_limit_exceeded',
      }),
    });

    renderWithIntl(
      <CVImportButton locale="en" cvImport={null} isSaving={false} onConfirmImport={() => {}} />,
    );

    const file = new File(['dummy content'], 'test.pdf', { type: 'application/pdf' });
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;

    await user.upload(input, file);

    await waitFor(() => {
      expect(notify.error).toHaveBeenCalledWith(
        "You've reached the CV import limit. Please wait a bit before trying again.",
      );
    });
  });

  it('shows an error and skips the request when an unsupported file is dropped', async () => {
    renderWithIntl(
      <CVImportButton locale="en" cvImport={null} isSaving={false} onConfirmImport={() => {}} />,
    );

    const dropZone = screen.getByText('or drag and drop PDF/DOCX').closest('div');
    expect(dropZone).toBeTruthy();

    const file = new File(['bad'], 'notes.txt', { type: 'text/plain' });
    fireEvent.drop(dropZone as HTMLDivElement, {
      dataTransfer: {
        files: [file],
      },
    });

    await waitFor(() => {
      expect(notify.error).toHaveBeenCalledWith('Only PDF and DOCX files are supported.');
    });
    expect(globalFetchMock).not.toHaveBeenCalled();
  });

  it('shows an error and skips the request when an empty file is selected', async () => {
    const user = userEvent.setup();

    renderWithIntl(
      <CVImportButton locale="en" cvImport={null} isSaving={false} onConfirmImport={() => {}} />,
    );

    const file = new File([], 'empty.pdf', { type: 'application/pdf' });
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;

    await user.upload(input, file);

    await waitFor(() => {
      expect(notify.error).toHaveBeenCalledWith('The selected file is empty.');
    });
    expect(globalFetchMock).not.toHaveBeenCalled();
  });

  // CV_PARSING_TIMEOUT_MS = 60_000; each stage duration = max(60000 - atMs, 1000)
  const TIMEOUT_MS = 60_000;
  const STAGE_DURATIONS = {
    0: TIMEOUT_MS, // atMs=0  → 60000
    8000: 52_000, // atMs=8000  → 52000
    18000: 42_000, // atMs=18000 → 42000
    30000: 30_000, // atMs=30000 → 30000
    45000: 15_000, // atMs=45000 → 15000
  };

  it('each toast stage uses a finite countdown duration (regression: must not be Infinity)', async () => {
    vi.useFakeTimers();
    let resolveFetch: ((value: any) => void) | undefined;
    globalFetchMock.mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          resolveFetch = resolve;
        }),
    );

    renderWithIntl(
      <CVImportButton locale="en" cvImport={null} isSaving={false} onConfirmImport={vi.fn()} />,
    );

    const input = document.querySelector('input[type="file"]') as HTMLInputElement;
    fireEvent.change(input, {
      target: { files: [new File(['x'], 'cv.pdf', { type: 'application/pdf' })] },
    });

    // First stage fires immediately
    expect(notify.info).toHaveBeenCalledWith('Uploading your CV...', {
      id: 'cv-import-progress',
      duration: STAGE_DURATIONS[0],
    });
    expect(notify.info).not.toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({ duration: Infinity }),
    );

    // Advance past the last stage
    await act(async () => {
      vi.advanceTimersByTime(50_000);
    });

    // All 5 stage calls must have a finite duration
    const infoCalls = (notify.info as ReturnType<typeof vi.fn>).mock.calls;
    for (const [, opts] of infoCalls) {
      expect(Number.isFinite((opts as { duration: number }).duration)).toBe(true);
    }

    resolveFetch?.({
      ok: true,
      json: async () => ({
        skills: [],
        values: [],
        warnings: [],
        metadata: {
          filename: 'cv.pdf',
          imported_at: '2023-10-01T12:00:00Z',
          source: 'cv_upload',
          locale: 'en',
        },
      }),
    });
    vi.useRealTimers();
  });

  it('updates the parsing toast when the import keeps running', async () => {
    vi.useFakeTimers();
    const handleConfirmImport = vi.fn();
    let resolveFetch: ((value: any) => void) | undefined;

    globalFetchMock.mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          resolveFetch = resolve;
        }),
    );

    renderWithIntl(
      <CVImportButton
        locale="en"
        cvImport={null}
        isSaving={false}
        onConfirmImport={handleConfirmImport}
      />,
    );

    const file = new File(['dummy content'], 'test.pdf', { type: 'application/pdf' });
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;

    fireEvent.change(input, { target: { files: [file] } });

    expect(notify.info).toHaveBeenNthCalledWith(1, 'Uploading your CV...', {
      id: 'cv-import-progress',
      duration: STAGE_DURATIONS[0],
    });

    await act(async () => {
      vi.advanceTimersByTime(15000);
    });

    expect(notify.info).toHaveBeenNthCalledWith(2, 'Parsing your CV, please wait...', {
      id: 'cv-import-progress',
      duration: STAGE_DURATIONS[8000],
    });

    await act(async () => {
      vi.advanceTimersByTime(30000);
    });

    expect(notify.info).toHaveBeenNthCalledWith(
      5,
      'Still working on your CV... This can take up to a minute. Please remain on this page while it finishes.',
      { id: 'cv-import-progress', duration: STAGE_DURATIONS[45000] },
    );

    await act(async () => {
      resolveFetch?.({
        ok: true,
        json: async () => ({
          skills: [],
          values: [],
          warnings: [],
          metadata: {
            filename: 'test.pdf',
            imported_at: '2023-10-01T12:00:00Z',
            source: 'cv_upload',
            locale: 'en',
          },
        }),
      });
      await Promise.resolve();
      await Promise.resolve();
    });

    expect(handleConfirmImport).toHaveBeenCalled();
    expect(notify.dismiss).toHaveBeenCalled();
    vi.useRealTimers();
  });
});
