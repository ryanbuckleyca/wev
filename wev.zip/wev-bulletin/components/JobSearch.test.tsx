import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, act, fireEvent } from '@/test-utils';
import userEvent from '@testing-library/user-event';
import JobSearch from './JobSearch';
import type { ActiveFilterChip } from './JobSearch';

const defaultProps = {
  searchQuery: '',
  onSearchChange: () => {},
  filtersExpanded: false,
  onFiltersExpandedChange: () => {},
  activeFilterChips: [] as ActiveFilterChip[],
  filteredJobsCount: 10,
  totalJobsCount: 50,
  hasAnyFilters: false,
  isSuggestedDefaults: true,
  onClearAllFilters: () => {},
  onApplySuggestedDefaults: () => {},
};

function renderJobSearch(overrides: Partial<typeof defaultProps> = {}) {
  return render(<JobSearch {...defaultProps} {...overrides} />);
}

describe('JobSearch', () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  it('renders the search input with an accessible label', () => {
    renderJobSearch();
    expect(screen.getByLabelText('Search jobs')).toBeVisible();
  });

  it('shows the current search query in the input', () => {
    renderJobSearch({ searchQuery: 'designer' });
    expect(screen.getByLabelText('Search jobs')).toHaveValue('designer');
  });

  it('calls onSearchChange when the user types', async () => {
    vi.useFakeTimers();
    const handleSearch = vi.fn();
    renderJobSearch({ onSearchChange: handleSearch });

    const input = screen.getByLabelText('Search jobs');
    fireEvent.change(input, { target: { value: 'a' } });

    // Should not be called immediately due to debounce
    expect(handleSearch).not.toHaveBeenCalled();

    // Advance time to trigger debounce
    await act(async () => {
      vi.advanceTimersByTime(300);
    });

    expect(handleSearch).toHaveBeenCalledWith('a');
  });

  it('shows a clear button when the search query is not empty', () => {
    renderJobSearch({ searchQuery: 'designer' });
    expect(screen.getByRole('button', { name: /clear search/i })).toBeVisible();
  });

  it('hides the clear button when the search query is empty', () => {
    renderJobSearch({ searchQuery: '' });
    expect(screen.queryByRole('button', { name: /clear search/i })).not.toBeInTheDocument();
  });

  it('clears the search input when the clear button is clicked', async () => {
    vi.useFakeTimers();
    const handleSearch = vi.fn();
    // Render with an initial query
    renderJobSearch({ searchQuery: 'designer', onSearchChange: handleSearch });

    const clearBtn = screen.getByRole('button', { name: /clear search/i });
    fireEvent.click(clearBtn);

    // The input should now be empty immediately
    expect(screen.getByLabelText('Search jobs')).toHaveValue('');

    // onSearchChange should not be called immediately
    expect(handleSearch).not.toHaveBeenCalled();

    // Advance time to trigger debounce
    await act(async () => {
      vi.advanceTimersByTime(300);
    });

    expect(handleSearch).toHaveBeenCalledWith('');
  });

  it('displays the filtered and total job counts', () => {
    renderJobSearch({ filteredJobsCount: 12, totalJobsCount: 100 });
    expect(screen.getByText('12')).toBeVisible();
    expect(screen.getByText(/of 100/)).toBeVisible();
  });

  it('uses the singular "job" when totalJobsCount is 1', () => {
    renderJobSearch({ filteredJobsCount: 1, totalJobsCount: 1 });
    expect(screen.getByText(/1 job$/)).toBeVisible();
  });

  it('uses the plural "jobs" when totalJobsCount is greater than 1', () => {
    renderJobSearch({ filteredJobsCount: 3, totalJobsCount: 5 });
    expect(screen.getByText(/5 jobs$/)).toBeVisible();
  });

  it('renders a filter toggle button showing the chip count', () => {
    const chips: ActiveFilterChip[] = [
      { id: '1', label: 'SSE only' },
      { id: '2', label: 'Posted: 2 weeks' },
    ];
    renderJobSearch({ activeFilterChips: chips });

    const filterBtn = screen.getByRole('button', { name: /filters/i });
    expect(filterBtn).toBeVisible();
    expect(filterBtn).toHaveTextContent('2');
  });

  it('calls onFiltersExpandedChange when the filter button is clicked', async () => {
    const user = userEvent.setup();
    const handleExpand = vi.fn();
    renderJobSearch({ onFiltersExpandedChange: handleExpand });

    await user.click(screen.getByRole('button', { name: /filters/i }));
    expect(handleExpand).toHaveBeenCalledWith(true);
    expect(handleExpand).toHaveBeenCalledOnce();
  });

  it('renders active filter chips as removable pills', () => {
    const chips: ActiveFilterChip[] = [
      { id: 'sse', label: 'SSE only', onRemove: () => {} },
      { id: 'posted', label: 'Posted: 2 weeks', onRemove: () => {} },
    ];
    renderJobSearch({ activeFilterChips: chips });

    expect(screen.getByText('SSE only')).toBeVisible();
    expect(screen.getByText('Posted: 2 weeks')).toBeVisible();
  });

  it('calls chip onRemove when the remove button on a chip is clicked', async () => {
    const user = userEvent.setup();
    const handleRemoveSse = vi.fn();
    const chips: ActiveFilterChip[] = [
      { id: 'sse', label: 'SSE only', onRemove: handleRemoveSse },
      { id: 'posted', label: 'Posted: 2 weeks', onRemove: () => {} },
    ];
    renderJobSearch({ activeFilterChips: chips, hasAnyFilters: true });

    // The Pill's remove button has an aria-label like "Remove"
    const removeButtons = screen.getAllByRole('button', { name: /remove/i });
    // Click the first remove button (SSE only chip)
    await user.click(removeButtons[0]);
    expect(handleRemoveSse).toHaveBeenCalledOnce();
  });

  it('shows "Clear all filters" link when filters are active', () => {
    renderJobSearch({ hasAnyFilters: true });
    expect(screen.getByRole('button', { name: 'Clear all filters' })).toBeVisible();
  });

  it('shows "Use suggested filters" link when not using suggested defaults', () => {
    renderJobSearch({ isSuggestedDefaults: false });
    expect(screen.getByRole('button', { name: 'Use suggested filters' })).toBeVisible();
  });

  it('calls onClearAllFilters when "Clear all filters" is clicked', async () => {
    const user = userEvent.setup();
    const handleClear = vi.fn();
    renderJobSearch({ hasAnyFilters: true, onClearAllFilters: handleClear });

    await user.click(screen.getByRole('button', { name: 'Clear all filters' }));
    expect(handleClear).toHaveBeenCalledOnce();
  });

  it('updates local search input when searchQuery prop changes externally', () => {
    const { rerender } = renderJobSearch({ searchQuery: 'initial' });
    expect(screen.getByLabelText('Search jobs')).toHaveValue('initial');

    rerender(<JobSearch {...defaultProps} searchQuery="" />);
    expect(screen.getByLabelText('Search jobs')).toHaveValue('');
  });

  it('calls onApplySuggestedDefaults when "Use suggested filters" is clicked', async () => {
    const user = userEvent.setup();
    const handleDefaults = vi.fn();
    renderJobSearch({ isSuggestedDefaults: false, onApplySuggestedDefaults: handleDefaults });

    await user.click(screen.getByRole('button', { name: 'Use suggested filters' }));
    expect(handleDefaults).toHaveBeenCalledOnce();
  });

  it('hides action links when no filters are active and defaults are applied', () => {
    renderJobSearch({ hasAnyFilters: false, isSuggestedDefaults: true });

    expect(screen.queryByRole('button', { name: 'Show all jobs' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Use suggested filters' })).not.toBeInTheDocument();
  });

  it('sets aria-expanded on the filter toggle button', () => {
    const { rerender } = render(<JobSearch {...defaultProps} filtersExpanded={false} />);
    expect(screen.getByRole('button', { name: /filters/i })).toHaveAttribute(
      'aria-expanded',
      'false',
    );

    rerender(<JobSearch {...defaultProps} filtersExpanded={true} />);
    expect(screen.getByRole('button', { name: /filters/i })).toHaveAttribute(
      'aria-expanded',
      'true',
    );
  });
});
