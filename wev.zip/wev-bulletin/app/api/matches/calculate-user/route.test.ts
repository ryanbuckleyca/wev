import { mockRequireAdminResponse } from '@/test-utils/require-admin-mock';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { POST } from './route';
import { calculateUserMatches } from '@/lib/match-calculator';
import { adminGateUnauthorized } from '@/test-utils/admin-route';

vi.mock('@/lib/match-calculator', () => ({
  calculateUserMatches: vi.fn(),
}));

const { mockSingle, mockSupabase } = vi.hoisted(() => {
  const mockSingle = vi.fn();
  const mockSupabase = {
    from: vi.fn(() => ({
      select: vi.fn(() => ({
        eq: vi.fn(() => ({
          single: mockSingle,
        })),
      })),
    })),
  };
  return { mockSingle, mockSupabase };
});

vi.mock('@/lib/supabase-server', () => ({
  supabaseServer: mockSupabase,
}));

const mockCalculateUserMatches = vi.mocked(calculateUserMatches);

describe('POST /api/matches/calculate-user', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockSingle.mockResolvedValue({ data: { id: 'user-1' }, error: null });
    mockCalculateUserMatches.mockResolvedValue(undefined);
    mockSupabase.from.mockReturnValue({
      select: vi.fn(() => ({
        eq: vi.fn(() => ({ single: mockSingle })),
      })),
    });
  });

  it('returns admin gate without calculating matches', async () => {
    mockRequireAdminResponse.mockResolvedValue(adminGateUnauthorized());

    const res = await POST(
      new Request('http://localhost/api/matches/calculate-user', {
        method: 'POST',
        body: JSON.stringify({ userId: 'user-1' }),
      }),
    );

    expect(res.status).toBe(401);
    expect(mockCalculateUserMatches).not.toHaveBeenCalled();
  });

  it('calculates matches when admin and user exists', async () => {
    mockRequireAdminResponse.mockResolvedValue(null);

    const res = await POST(
      new Request('http://localhost/api/matches/calculate-user', {
        method: 'POST',
        body: JSON.stringify({ userId: 'user-1' }),
      }),
    );

    expect(res.status).toBe(200);
    expect(await res.json()).toMatchObject({ success: true });
    expect(mockCalculateUserMatches).toHaveBeenCalledWith('user-1');
  });

  it('returns 400 when userId is missing', async () => {
    mockRequireAdminResponse.mockResolvedValue(null);

    const res = await POST(
      new Request('http://localhost/api/matches/calculate-user', {
        method: 'POST',
        body: JSON.stringify({}),
      }),
    );

    expect(res.status).toBe(400);
    expect(mockCalculateUserMatches).not.toHaveBeenCalled();
  });

  it('returns 404 when profile not found', async () => {
    mockRequireAdminResponse.mockResolvedValue(null);
    mockSingle.mockResolvedValue({ data: null, error: { message: 'not found' } });

    const res = await POST(
      new Request('http://localhost/api/matches/calculate-user', {
        method: 'POST',
        body: JSON.stringify({ userId: 'missing' }),
      }),
    );

    expect(res.status).toBe(404);
    expect(mockCalculateUserMatches).not.toHaveBeenCalled();
  });
});
