'use client';

import Link from 'next/link';
import Image from 'next/image';
import Button from '@/components/Button';
import LinkButton from '@/components/LinkButton';
import StyledLink from '@/components/StyledLink';
import ButtonLink from '@/components/ButtonLink';
import BannerMessage from '@/components/BannerMessage';
import notify from '@/lib/toast';
import { SITE_CONFIG } from '@/lib/site-config';
import { useState, useEffect } from 'react';

export const dynamic = 'force-dynamic';

const LOGO_MARK =
  'https://teuvfoftdjfsnkkbnzps.supabase.co/storage/v1/object/public/bulletin/wev-logo.png';

// Convert a #rrggbb hex string to a "r, g, b" string. Returns '' for non-hex input.
const hexToRgb = (hex: string) => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}`
    : '';
};

interface Token {
  name: string;
  value: string;
  swatch: string;
  border: boolean;
}

export default function StyleGuidePage() {
  const [allTokens, setAllTokens] = useState<Token[]>([]);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const formatTokenName = (cssVar: string) =>
      cssVar
        .replace('--', '')
        .split('-')
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join('');

    const style = getComputedStyle(document.documentElement);
    const tokens: Token[] = [];

    const colorFilterKeywords = [
      'primary',
      'secondary',
      'accent',
      'neutral',
      'success',
      'warning',
      'error',
      'background',
      'foreground',
      'muted',
      'border',
      'input',
      'ring',
      'card',
      'popover',
      'text',
    ];

    for (let i = 0; i < style.length; i++) {
      const prop = style[i];
      if (!prop.startsWith('--')) continue;

      const value = style.getPropertyValue(prop).trim();
      if (!value || value === 'initial' || value === 'inherit') continue;

      // Check for colors (hex, rgb, hsl) or matching keywords
      const isColorValue =
        value.startsWith('#') || value.startsWith('rgb') || value.startsWith('hsl');
      const matchesKeyword = colorFilterKeywords.some((kw) => prop.includes(kw));

      if (isColorValue || matchesKeyword) {
        tokens.push({
          name: formatTokenName(prop),
          value: `var(${prop})`,
          swatch: `var(${prop})`,
          border: prop.includes('border'),
        });
      }
    }

    // Use requestAnimationFrame to decouple state update from the effect block,
    // avoiding synchronous cascading renders and satisfying the linter.
    requestAnimationFrame(() => {
      setAllTokens(tokens);
    });
  }, []);

  return (
    <>
      {/* Hero */}
      <div className="design-hero">
        <div className="design-hero-content">
          <div className="logo-display">
            <Image
              src={SITE_CONFIG.logotypeUrl}
              alt="wev logo"
              width={160}
              height={64}
              unoptimized
              className="wev-logotype"
            />
          </div>
          <p className="design-subtitle">Style Guide</p>
          <p className="design-version">Version 1.2 • June 2026</p>
        </div>
      </div>

      {/* Logo */}
      <section id="logo" className="design-section">
        <div className="design-container">
          <h2>Logo Usage</h2>
          <p className="design-section-intro">
            Our logo represents clarity and connection. Always maintain proper spacing and never
            distort or alter the colors.
          </p>

          <div className="design-logo-grid">
            <div className="design-logo-showcase design-logo-bg-light">
              <div className="design-logo-placeholder">
                <Image
                  src={SITE_CONFIG.logotypeUrl}
                  alt="wev logo"
                  width={200}
                  height={80}
                  unoptimized
                  className="wev-logotype"
                />
              </div>
              <div className="design-logo-title">Primary Logotype</div>
              <p className="design-logo-description">
                Full logo with brand name for primary applications
              </p>
            </div>

            <div className="design-logo-showcase design-logo-bg-light">
              <div className="design-logo-placeholder">
                <Image src={LOGO_MARK} alt="wev logo mark" width={120} height={120} />
              </div>
              <div className="design-logo-title">Logo Mark</div>
              <p className="design-logo-description">
                Standalone icon for compact use (favicon, app icons)
              </p>
            </div>
          </div>

          <h3>Logo Guidelines</h3>
          <div className="mt-8">
            <h4>Clear Space</h4>
            <p className="text-muted-foreground mb-8">
              Maintain clear space around the logo equal to the height of the 'w'. This ensures
              visual distinction.
            </p>

            <h4>Minimum Size</h4>
            <p className="text-muted-foreground mb-4">
              <strong>Digital:</strong> 32px height minimum for logo mark, 120px width for logotype
              <br />
              <strong>Print:</strong> 0.5 inches height minimum for logo mark, 1.5 inches for
              logotype
            </p>

            <h4 className="mt-8">Don'ts</h4>
            <ul className="text-muted-foreground leading-relaxed ml-6 list-disc space-y-1">
              <li>Do not alter logo colors outside approved palette</li>
              <li>Do not distort, rotate, or skew the logo</li>
              <li>Do not add effects (shadows, outlines, gradients)</li>
              <li>Do not place on busy backgrounds without sufficient contrast</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Typography */}
      <section id="typography" className="design-section">
        <div className="design-container">
          <h2>Typography</h2>
          <p className="design-section-intro">
            Lexend Deca is our primary typeface. Designed specifically for readability and
            accessibility, it ensures our content is clear and approachable across all platforms.
          </p>

          <h3>Font Family</h3>
          <div className="design-font-specimen">
            <div className="design-font-name">Lexend Deca</div>
            <div className="design-font-meta">
              Sans-serif • Available on{' '}
              <a
                href="https://fonts.google.com/specimen/Lexend+Deca"
                target="_blank"
                rel="noopener noreferrer"
                className="design-accent-link"
              >
                Google Fonts
              </a>
            </div>
            <div className="design-font-charset">
              ABCDEFGHIJKLMNOPQRSTUVWXYZ
              <br />
              abcdefghijklmnopqrstuvwxyz
              <br />
              0123456789 !@#$%&amp;*()
            </div>
          </div>

          <h3>Weights</h3>
          <div className="design-weight-grid">
            <div className="design-weight-example">
              <div className="design-weight-label">Regular / 400</div>
              <div className="design-weight-sample" style={{ fontWeight: 400 }}>
                The quick brown fox jumps over the lazy dog
              </div>
            </div>
            <div className="design-weight-example">
              <div className="design-weight-label">Medium / 500</div>
              <div className="design-weight-sample" style={{ fontWeight: 500 }}>
                The quick brown fox jumps over the lazy dog
              </div>
            </div>
            <div className="design-weight-example">
              <div className="design-weight-label">Semi-Bold / 600</div>
              <div className="design-weight-sample" style={{ fontWeight: 600 }}>
                The quick brown fox jumps over the lazy dog
              </div>
            </div>
            <div className="design-weight-example">
              <div className="design-weight-label">Bold / 700</div>
              <div className="design-weight-sample" style={{ fontWeight: 700 }}>
                The quick brown fox jumps over the lazy dog
              </div>
            </div>
          </div>

          <h3>Type Scale</h3>
          <div className="design-type-scale">
            <div className="design-type-example">
              <div className="design-type-label">H1 / 32px / Bold</div>
              <div className="design-type-specimen design-type-h1">The quick brown fox jumps</div>
            </div>
            <div className="design-type-example">
              <div className="design-type-label">H2 / 28px / Semi-Bold</div>
              <div className="design-type-specimen design-type-h2">The quick brown fox jumps</div>
            </div>
            <div className="design-type-example">
              <div className="design-type-label">H3 / 24px / Semi-Bold</div>
              <div className="design-type-specimen design-type-h3">The quick brown fox jumps</div>
            </div>
            <div className="design-type-example">
              <div className="design-type-label">H4 / 20px / Medium</div>
              <div className="design-type-specimen design-type-h4">The quick brown fox jumps</div>
            </div>
            <div className="design-type-example">
              <div className="design-type-label">Body Large / 18px</div>
              <div className="design-type-specimen design-type-body-large">
                The quick brown fox jumps over the lazy dog
              </div>
            </div>
            <div className="design-type-example">
              <div className="design-type-label">Body / 16px</div>
              <div className="design-type-specimen design-type-body">
                The quick brown fox jumps over the lazy dog
              </div>
            </div>
            <div className="design-type-example">
              <div className="design-type-label">Body Small / 14px</div>
              <div className="design-type-specimen design-type-body-small">
                The quick brown fox jumps over the lazy dog
              </div>
            </div>
            <div className="design-type-example">
              <div className="design-type-label">Button / 16px / Semi-Bold</div>
              <div className="design-type-specimen design-type-button">BUTTON TEXT</div>
            </div>
          </div>
        </div>
      </section>

      {/* Design Tokens / Color Palette */}
      <section id="tokens" className="design-section">
        <div className="design-container">
          <h2>Color Tokens</h2>
          <p className="design-section-intro">
            Our color system balances warmth and professionalism, and every value is exposed as a
            design token for consistent implementation across platforms and frameworks. All colors
            are tested for WCAG 2.1 AA compliance.
          </p>

          <p className="design-token-hint">Click any value to copy it to your clipboard.</p>
          <ColorTokenSheet tokens={allTokens} />
        </div>
      </section>

      {/* Accessibility */}
      <section id="accessibility" className="design-section">
        <div className="design-container">
          <h2>Accessibility</h2>
          <p className="design-section-intro">
            All color combinations meet WCAG 2.1 Level AA standards. We prioritize inclusive design
            to ensure our products are accessible to everyone.
          </p>

          <h3>Contrast Test Results</h3>
          <div className="design-contrast-grid">
            <ContrastCard
              bg="#FEFBF7"
              color="#875C74"
              text="Dusty Lavender on Porcelain"
              ratio="5.8:1"
              badge="✓ AA Pass"
            />
            <ContrastCard
              bg="#5B8C8A"
              color="#ffffff"
              text="White on Muted Teal"
              ratio="5.1:1"
              badge="✓ AA Pass"
            />
            <ContrastCard
              bg="#FEFBF7"
              color="#2a2a2a"
              text="Charcoal on Porcelain"
              ratio="13.5:1"
              badge="✓ AAA Pass"
            />
            <ContrastCard
              bg="#C5EBC3"
              color="#2a2a2a"
              text="Text on Tea Green"
              ratio="8.2:1"
              badge="✓ AAA Pass"
            />
            <ContrastCard
              bg="#F5DEB3"
              color="#2a2a2a"
              text="Text on Warning Tint"
              ratio="6.4:1"
              badge="✓ AA Pass"
            />
            <ContrastCard
              bg="#F2D0CC"
              color="#2a2a2a"
              text="Text on Alert Tint"
              ratio="5.9:1"
              badge="✓ AA Pass"
            />
          </div>

          <h3 className="mt-16">Dark Mode Contrast Tests</h3>
          <div className="design-contrast-grid">
            <ContrastCard
              bg="#1E1E1E"
              color="#B07D96"
              text="Dusty Lavender Light on Dark"
              ratio="7.2:1"
              badge="✓ AAA Pass"
            />
            <ContrastCard
              bg="#1E1E1E"
              color="#5B8C8A"
              text="Muted Teal on Dark"
              ratio="6.8:1"
              badge="✓ AA Pass"
            />
            <ContrastCard
              bg="#1E1E1E"
              color="#E8E6E2"
              text="White on Charcoal Deep"
              ratio="16.1:1"
              badge="✓ AAA Pass"
            />
            <ContrastCard
              bg="#5B8C8A"
              color="#1E1E1E"
              text="Dark on Muted Teal (CTA)"
              ratio="5.9:1"
              badge="✓ AA Pass"
            />
            <ContrastCard
              bg="#1A3320"
              color="#6FD68A"
              text="Success Text on Tint"
              ratio="7.8:1"
              badge="✓ AAA Pass"
            />
            <ContrastCard
              bg="#3D1F1C"
              color="#E8857A"
              text="Alert Text on Tint"
              ratio="6.9:1"
              badge="✓ AA Pass"
            />
            <ContrastCard
              bg="#3A2E0A"
              color="#E8B53A"
              text="Warning Text on Tint"
              ratio="8.2:1"
              badge="✓ AAA Pass"
            />
            <ContrastCard
              bg="#1C2E3D"
              color="#7AB4D9"
              text="Info Text on Tint"
              ratio="7.5:1"
              badge="✓ AAA Pass"
            />
            <ContrastCard
              bg="#1E1E1E"
              color="#A8A5A0"
              text="Secondary Text on Dark"
              ratio="9.8:1"
              badge="✓ AAA Pass"
            />
          </div>

          <h3>Best Practices</h3>
          <ul className="mt-8 ml-6 list-disc flex flex-col gap-4 text-muted-foreground leading-relaxed">
            <li>Test all color combinations with contrast checking tools before implementation</li>
            <li>Never rely on color alone to convey information—use icons, labels, or patterns</li>
            <li>Ensure interactive elements have minimum target size of 44×44px</li>
            <li>Maintain visible focus indicators on all interactive elements</li>
            <li>Use Lexend Deca font for improved readability for users with dyslexia</li>
            <li>Provide alternative text for all images and icons</li>
            <li>Ensure sufficient line height (1.5× minimum) for readability</li>
          </ul>
        </div>
      </section>

      {/* Component System */}
      <section id="three-component-system" className="design-section">
        <div className="design-container">
          <h2>Component System</h2>
          <p className="design-section-intro">
            We use four distinct components for interaction patterns: Button for actions, LinkButton
            for navigation that looks like buttons, StyledLink for navigation with flexible styling,
            and ButtonLink for actions that should look like inline links.
          </p>

          <div className="design-button-grid">
            <div className="design-button-example">
              <div className="design-button-label">Button Component</div>
              <p className="design-button-description">
                Pure actions that don&apos;t navigate. Form submission, modals, API calls, state
                changes.
              </p>
              <div className="flex flex-wrap gap-2">
                <Button type="button">Save Changes</Button>
                <Button variant="secondary">Copy to Clipboard</Button>
                <Button variant="outline">Cancel</Button>
              </div>
              <div className="design-usage-examples">
                <p className="text-sm text-muted-foreground mt-4">
                  <strong>Variants:</strong> primary, secondary, outline
                </p>
              </div>
            </div>

            <div className="design-button-example">
              <div className="design-button-label">LinkButton Component</div>
              <p className="design-button-description">
                Navigation that looks exactly like a button. Same visual variants as Button.
              </p>
              <div className="flex flex-wrap gap-2">
                <LinkButton href="/profile">View Profile</LinkButton>
                <LinkButton href="/" variant="secondary">
                  Back to Jobs
                </LinkButton>
                <LinkButton href="/style-guide" variant="outline">
                  Learn More
                </LinkButton>
              </div>
              <div className="design-usage-examples">
                <p className="text-sm text-muted-foreground mt-4">
                  <strong>Variants:</strong> primary, secondary, outline (same as Button)
                </p>
              </div>
            </div>

            <div className="design-button-example">
              <div className="design-button-label">StyledLink Component</div>
              <p className="design-button-description">
                Navigation with flexible styling - can look like button or text.
              </p>
              <div className="flex flex-wrap gap-2">
                <StyledLink href="/profile" variant="primary">
                  View Profile
                </StyledLink>
                <StyledLink href="/" variant="secondary">
                  Back to Jobs
                </StyledLink>
                <StyledLink href="/style-guide" variant="outline">
                  Learn More
                </StyledLink>
                <StyledLink href="/style-guide" variant="text">
                  Documentation
                </StyledLink>
              </div>
              <div className="design-usage-examples">
                <p className="text-sm text-muted-foreground mt-4">
                  <strong>Variants:</strong> primary, secondary, outline, text
                </p>
              </div>
            </div>

            <div className="design-button-example">
              <div className="design-button-label">ButtonLink Component</div>
              <p className="design-button-description">
                Actions that should look like links (toggle/collapse, clear, reset). This stays a
                semantic button.
              </p>
              <div className="flex flex-wrap gap-3 items-center">
                <ButtonLink onClick={() => undefined}>Collapse all</ButtonLink>
                <ButtonLink tone="muted" size="xs" className="underline" onClick={() => undefined}>
                  Show all jobs
                </ButtonLink>
                <ButtonLink tone="primary" onClick={() => undefined}>
                  Use suggested filters
                </ButtonLink>
              </div>
              <div className="design-usage-examples">
                <p className="text-sm text-muted-foreground mt-4">
                  <strong>Tones:</strong> accent, muted, primary
                </p>
              </div>
            </div>
          </div>

          <h3>Button Layout Guidelines</h3>
          <div className="design-layout-grid">
            <div className="design-layout-example">
              <div className="design-layout-label">Two-Button Layouts</div>
              <p className="design-layout-description">
                Secondary actions (cancel, back) on left, primary actions (save, submit) on right.
              </p>
              <div className="design-layout-preview">
                <div className="flex justify-between gap-3">
                  <LinkButton href="/" variant="outline">
                    Back to Jobs
                  </LinkButton>
                  <Button type="submit">Save Profile</Button>
                </div>
              </div>
              <div className="design-layout-code">
                <code className="text-xs bg-card p-2 rounded block">
                  &lt;div className="flex justify-between gap-3"&gt;
                  <br />
                  &nbsp;&nbsp;&lt;LinkButton href="/" variant="outline"&gt;
                  <br />
                  &nbsp;&nbsp;&nbsp;&nbsp;Back to Jobs
                  <br />
                  &nbsp;&nbsp;&lt;/LinkButton&gt;
                  <br />
                  &nbsp;&nbsp;&lt;Button type="submit"&gt;
                  <br />
                  &nbsp;&nbsp;&nbsp;&nbsp;Save Profile
                  <br />
                  &nbsp;&nbsp;&lt;/Button&gt;
                  <br />
                  &lt;/div&gt;
                </code>
              </div>
            </div>

            <div className="design-layout-example">
              <div className="design-layout-label">Single Button Layouts</div>
              <p className="design-layout-description">
                Single primary actions should be right-aligned for consistency.
              </p>
              <div className="design-layout-preview">
                <div className="flex justify-end gap-3">
                  <Button type="submit">Submit Application</Button>
                </div>
              </div>
              <div className="design-layout-code">
                <code className="text-xs bg-card p-2 rounded block">
                  &lt;div className="flex justify-end gap-3"&gt;
                  <br />
                  &nbsp;&nbsp;&lt;Button type="submit"&gt;
                  <br />
                  &nbsp;&nbsp;&nbsp;&nbsp;Submit Application
                  <br />
                  &nbsp;&nbsp;&lt;/Button&gt;
                  <br />
                  &lt;/div&gt;
                </code>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Buttons */}
      <section id="buttons" className="design-section">
        <div className="design-container">
          <h2>Button Hierarchy</h2>
          <p className="design-section-intro">
            Our button system creates clear visual hierarchy. Use primary buttons for main actions,
            secondary for supporting actions, and outline for low-emphasis interactions.
          </p>

          <div className="design-button-grid">
            <div className="design-button-example">
              <div className="design-button-label">Primary Button</div>
              <p className="design-button-description">
                Main action, one per view. Uses Muted Teal.
              </p>
              <div className="space-y-2">
                <Button type="button">Save Changes</Button>
                <Button type="button" disabled>
                  Disabled
                </Button>
              </div>
            </div>

            <div className="design-button-example">
              <div className="design-button-label">Secondary Button</div>
              <p className="design-button-description">
                Supporting action with teal outline and fill on hover.
              </p>
              <div className="space-y-2">
                <Button variant="secondary">Copy to Clipboard</Button>
                <Button variant="secondary" disabled>
                  Disabled
                </Button>
              </div>
            </div>

            <div className="design-button-example">
              <div className="design-button-label">Outline Button</div>
              <p className="design-button-description">Low-emphasis, border-only style.</p>
              <div className="space-y-2">
                <Button variant="outline">Cancel</Button>
                <Button variant="outline" disabled>
                  Disabled
                </Button>
              </div>
            </div>
          </div>

          <h3>Navigation Components</h3>
          <p className="design-section-intro">
            Navigation components use the same visual styles as buttons. LinkButton and StyledLink
            default to <code className="text-sm">prefetch=&#123;false&#125;</code>; pass{' '}
            <code className="text-sm">prefetch=&#123;true&#125;</code> when you want Next.js to
            prefetch that route.
          </p>

          <div className="design-button-grid">
            <div className="design-button-example">
              <div className="design-button-label">LinkButton (Primary)</div>
              <p className="design-button-description">
                Navigation that looks like a primary button.
              </p>
              <div className="space-y-2">
                <LinkButton href="/profile">View Profile</LinkButton>
                <LinkButton href="/profile" className="opacity-50">
                  Disabled State
                </LinkButton>
              </div>
            </div>

            <div className="design-button-example">
              <div className="design-button-label">LinkButton (Secondary)</div>
              <p className="design-button-description">
                Navigation with teal outline and fill on hover.
              </p>
              <div className="space-y-2">
                <LinkButton href="/" variant="secondary">
                  Back to Jobs
                </LinkButton>
                <LinkButton href="/" variant="secondary" className="opacity-50">
                  Disabled State
                </LinkButton>
              </div>
            </div>

            <div className="design-button-example">
              <div className="design-button-label">LinkButton (Outline)</div>
              <p className="design-button-description">Navigation with outline styling.</p>
              <div className="space-y-2">
                <LinkButton href="/style-guide" variant="outline">
                  Learn More
                </LinkButton>
                <LinkButton href="/style-guide" variant="outline" className="opacity-50">
                  Disabled State
                </LinkButton>
              </div>
            </div>
          </div>

          <h3>Text Links</h3>
          <p className="design-section-intro">
            Text links use theme colors with standard web conventions.
          </p>

          <div className="design-button-grid">
            <div className="design-button-example">
              <div className="design-button-label">StyledLink (Text)</div>
              <p className="design-button-description">Text-style navigation with theme colors.</p>
              <div className="space-y-2">
                <StyledLink href="/style-guide" variant="text">
                  Documentation
                </StyledLink>
                <br />
                <StyledLink href="/style-guide" variant="text">
                  Help Center
                </StyledLink>
              </div>
            </div>

            <div className="design-button-example">
              <div className="design-button-label">Standard Link</div>
              <p className="design-button-description">
                Raw i18n Link with theme colors; uses Next.js prefetch defaults unless overridden.
              </p>
              <div className="space-y-2">
                <Link
                  href="/profile"
                  className="text-[var(--primary)] hover:underline visited:text-[var(--brand-accent)]"
                >
                  View Profile
                </Link>
                <br />
                <Link
                  href="/style-guide"
                  className="text-[var(--primary)] hover:underline visited:text-[var(--brand-accent)]"
                  prefetch={false}
                >
                  Help Documentation (prefetch off)
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Alerts & Toasts */}
      <section id="alerts" className="design-section">
        <div className="design-container">
          <h2>Semantic States</h2>
          <p className="design-section-intro">
            Consistent visual feedback across success, error, warning, and info states. All
            combinations meet WCAG AA contrast requirements.
          </p>

          <h3>Banner Messages</h3>
          <BannerMessage type="success" message="Success: Your profile has been updated" />
          <BannerMessage type="error" message="Alert: Unable to connect to server" />
          <BannerMessage type="warning" message="Warning: Unsaved changes will be lost" />
          <BannerMessage type="info" message="Info: Maintenance scheduled for tonight" />

          <h3>Toast Messages</h3>
          <p className="design-section-intro">
            Toasts are a temporary pop-up version of Banner Messages. Click the links below to see
            each toast type in action with the live styling.
          </p>

          <div className="design-button-grid">
            <div className="design-button-example">
              <div className="design-button-label">Success Toast</div>
              <p className="design-button-description">
                Shows a success notification with green styling.
              </p>
              <button
                onClick={() => {
                  notify.success('Your profile has been updated successfully!');
                }}
                className="text-[var(--primary)] hover:underline"
              >
                Trigger Success Toast
              </button>
            </div>

            <div className="design-button-example">
              <div className="design-button-label">Error Toast</div>
              <p className="design-button-description">
                Shows an error notification with red styling.
              </p>
              <button
                onClick={() => {
                  notify.error('Failed to save changes. Please try again.');
                }}
                className="text-[var(--primary)] hover:underline"
              >
                Trigger Error Toast
              </button>
            </div>

            <div className="design-button-example">
              <div className="design-button-label">Warning Toast</div>
              <p className="design-button-description">
                Shows a warning notification with orange styling.
              </p>
              <button
                onClick={() => {
                  notify.warning('Your session will expire in 5 minutes.');
                }}
                className="text-[var(--primary)] hover:underline"
              >
                Trigger Warning Toast
              </button>
            </div>

            <div className="design-button-example">
              <div className="design-button-label">Info Toast</div>
              <p className="design-button-description">
                Shows an info notification with blue styling.
              </p>
              <button
                onClick={() => {
                  notify.info('Processing your request...');
                }}
                className="text-[var(--primary)] hover:underline"
              >
                Trigger Info Toast
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <section id="footer" className="design-footer design-section">
        <div className="design-container">
          <p>wev Style Guide • Version 1.2 • June 2026</p>
          <p>For questions about brand implementation, contact design@wevchange.org</p>
          <p className="mt-4">
            <Link
              href="/"
              className="underline opacity-80 hover:opacity-100"
              style={{ color: 'var(--background)' }}
            >
              ← Back to Bulletin
            </Link>
          </p>
        </div>
      </section>
    </>
  );
}

function ContrastCard({
  bg,
  color,
  text,
  ratio,
  badge,
}: {
  bg: string;
  color: string;
  text: string;
  ratio: string;
  badge: string;
}) {
  return (
    <div className="design-contrast-card">
      <div className="design-contrast-preview" style={{ background: bg, color }}>
        {text}
      </div>
      <div className="design-contrast-info">
        <span className="design-contrast-ratio">{ratio}</span>
        <span className="design-contrast-badge">{badge}</span>
      </div>
    </div>
  );
}

function ColorTokenSheet({ tokens }: { tokens: Token[] }) {
  const [showAll, setShowAll] = useState(false);

  const tokenCategories = tokens.reduce(
    (categories: Record<string, Token[]>, token: Token) => {
      let category = 'Other';
      if (
        token.name.includes('Bg') ||
        token.name.includes('Surface') ||
        token.name.includes('Border')
      ) {
        category = 'Background & Surface';
      } else if (token.name.includes('Text')) {
        category = 'Text Colors';
      } else if (token.name.includes('Primary') || token.name.includes('Accent')) {
        category = 'Brand Colors';
      } else if (
        token.name.includes('Success') ||
        token.name.includes('Alert') ||
        token.name.includes('Warn') ||
        token.name.includes('Info')
      ) {
        category = 'Semantic Colors';
      }

      if (!categories[category]) {
        categories[category] = [];
      }
      categories[category].push(token);
      return categories;
    },
    {} as Record<string, Token[]>,
  );

  const renderCategory = (category: string, categoryTokens: Token[]) => (
    <div key={category} className="design-token-category">
      <div className="design-token-category-title">{category}</div>
      <div className="design-token-row design-token-head">
        <span>Preview</span>
        <span>Token</span>
        <span>HEX</span>
        <span>RGB</span>
        <span>Variable</span>
      </div>
      {categoryTokens.map((token) => (
        <TokenRow
          key={token.name}
          name={token.name}
          value={token.value}
          swatch={token.swatch}
          border={token.border}
        />
      ))}
    </div>
  );

  const brandColors = tokenCategories['Brand Colors'];
  const otherCategories = Object.entries(tokenCategories)
    .filter(([category]) => category !== 'Brand Colors')
    .sort(([a], [b]) => a.localeCompare(b));

  return (
    <>
      <div className="design-token-sheet">
        {brandColors && renderCategory('Brand Colors', brandColors)}
        {showAll &&
          otherCategories.map(([category, categoryTokens]) =>
            renderCategory(category, categoryTokens),
          )}
      </div>
      {otherCategories.length > 0 && (
        <button
          type="button"
          className="design-token-toggle"
          onClick={() => setShowAll((prev) => !prev)}
          aria-expanded={showAll}
        >
          {showAll ? 'Show less' : 'Show all color tokens'}
        </button>
      )}
    </>
  );
}

function TokenRow({
  name,
  value,
  swatch,
  border,
}: {
  name: string;
  value: string;
  swatch: string;
  border?: boolean;
}) {
  const [hex, setHex] = useState('');
  const [rgb, setRgb] = useState('');

  useEffect(() => {
    const cssVarName = value.replace('var(', '').replace(')', '').trim();
    const resolved = getComputedStyle(document.documentElement).getPropertyValue(cssVarName).trim();
    setHex(resolved);
    setRgb(resolved.startsWith('#') ? hexToRgb(resolved) : '');
  }, [value]);

  const copy = (text: string, label: string) => {
    if (!text || !navigator.clipboard) return;
    navigator.clipboard.writeText(text).then(
      () => notify.success(`Copied ${label}: ${text}`),
      () => notify.error('Failed to copy to clipboard'),
    );
  };

  const rgbValue = rgb ? `rgb(${rgb})` : '';

  return (
    <div className="design-token-row">
      <div
        className="design-token-swatch"
        style={{
          background: swatch,
          ...(border ? { border: '2px solid #c8c5bf' } : {}),
        }}
      />
      <div className="design-token-name">{name}</div>
      <button
        type="button"
        className="design-token-copy"
        onClick={() => copy(hex, 'HEX')}
        disabled={!hex}
      >
        {hex || '—'}
      </button>
      <button
        type="button"
        className="design-token-copy"
        onClick={() => copy(rgbValue, 'RGB')}
        disabled={!rgbValue}
      >
        {rgbValue || '—'}
      </button>
      <button type="button" className="design-token-copy" onClick={() => copy(value, 'token')}>
        {value}
      </button>
    </div>
  );
}
