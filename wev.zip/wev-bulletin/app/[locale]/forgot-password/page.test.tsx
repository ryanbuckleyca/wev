import { beforeEach, describe, expect, it, vi } from 'vitest';
import userEvent from '@testing-library/user-event';
import { render, screen, waitFor } from '@/test-utils';
import ForgotPasswordPage from './page';
import { createClient } from '@/lib/supabase/client';

vi.mock('@/lib/supabase/client', () => ({
  createClient: vi.fn(),
}));

vi.mock('@/i18n/navigation', () => import('@/test-utils/i18n-navigation-mock'));

vi.mock('@/components/TurnstileWidget', () => import('@/test-utils/turnstile-widget-mock'));

const mockResetPasswordForEmail = vi.fn();

describe('ForgotPasswordPage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockResetPasswordForEmail.mockResolvedValue({ error: null });
    vi.mocked(createClient).mockReturnValue({
      auth: {
        resetPasswordForEmail: mockResetPasswordForEmail,
      },
    } as never);
  });

  it('shows the shared check email state after requesting a reset link', async () => {
    const user = userEvent.setup();
    render(<ForgotPasswordPage />);

    await user.type(screen.getByPlaceholderText('you@example.com'), 'test@example.com');
    await user.click(screen.getByRole('button', { name: /complete captcha/i }));
    await user.click(screen.getByRole('button', { name: /send reset link/i }));

    await waitFor(() => {
      expect(mockResetPasswordForEmail).toHaveBeenCalledWith(
        'test@example.com',
        expect.objectContaining({
          redirectTo: expect.any(String),
          captchaToken: 'turnstile-token',
        }),
      );
    });

    expect(screen.getByRole('heading', { name: /check your email/i })).toBeVisible();
    expect(
      screen.getByText(/if an account exists for this email, we['’]ll send you a link/i),
    ).toBeVisible();
    expect(screen.getByRole('button', { name: /try again in 30s/i })).toBeDisabled();
    expect(screen.getByRole('link', { name: /log in/i })).toBeVisible();
  });
});
