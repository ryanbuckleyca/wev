import { VALUES_DICTIONARY, VALUES_LIST } from '@/lib/values';
import type { CvLocale } from './types';

export const MAX_TEXT_CHARS = 12_000;
export const MAX_VALUES = 5;
export const PROMPT_VERSION = 3;

export const RERANK_CV_SNIPPET_CHARS = 3_000;
export const RERANK_DESCRIPTION_CHARS = 200;

function truncateAtWord(text: string, maxLen: number): string {
  if (text.length <= maxLen) return text;
  const sliced = text.slice(0, maxLen);
  const lastSpace = Math.max(sliced.lastIndexOf(' '), sliced.lastIndexOf('\n'));
  return lastSpace > 0 ? sliced.slice(0, lastSpace) : sliced;
}

export type RerankCandidate = {
  conceptUri: string;
  label: string;
  description: string;
};

function formatRerankCandidates(candidates: RerankCandidate[]): string {
  return candidates
    .map((c, i) => {
      const desc = c.description
        ? ` — ${c.description.slice(0, RERANK_DESCRIPTION_CHARS)}`
        : '';
      return `${i + 1}. [${c.conceptUri}] ${c.label}${desc}`;
    })
    .join('\n');
}

export function buildRerankPrompt(
  cvText: string,
  candidates: RerankCandidate[],
  maxSkills: number,
  locale: CvLocale = 'en',
): string {
  const cvSnippet = truncateAtWord(cvText, RERANK_CV_SNIPPET_CHARS);
  const candidateList = formatRerankCandidates(candidates);

  if (locale === 'fr') {
    return `Tu evalues strictement les competences ESCO par rapport au CV d'une candidate ou d'un candidat.

CV (extrait):
"""
${cvSnippet}
"""

Competences ESCO candidates:
${candidateList}

TACHE: Selectionne jusqu'a ${maxSkills} competences de la liste ci-dessus que cette personne a clairement demontrees. Vise ${maxSkills} mais retourne moins si necessaire.

REGLES DE REJET STRICTES — rejette une competence si UNE des conditions suivantes s'applique:
1. La description de la competence mentionne un domaine (TIC, technologie, logiciel, numerique, clinique, medical, agricole, marin, juridique, scientifique de type test d'hypotheses) qui n'est PAS mentionne dans le CV
2. Le libelle de la competence contient un qualificatif de domaine (par ex. "TIC", "Agile", "Lean", "scientifique", "clinique") qui n'apparait pas dans le texte du CV
3. La description decrit des activites que la personne n'a pas effectuees, meme si le libelle parait pertinent

CRITERES DE SELECTION:
- L'experience professionnelle reelle de la personne, pas seulement le chevauchement de mots-cles avec le libelle
- Privilegie les libelles de competences larges et transferables aux variantes specifiques a un domaine
- "gestion de projet" est acceptable; "gestion de projet TIC" ne l'est pas a moins que le CV mentionne les TIC

Retourne du JSON: {"selected": ["uri1", "uri2", ...]} — uniquement des URIs de la liste ci-dessus, exactement tels qu'ecrits.`;
  }

  return `You are a strict skills assessor matching ESCO skills to a candidate's CV.

CV (excerpt):
"""
${cvSnippet}
"""

Candidate ESCO skills:
${candidateList}

TASK: Select up to ${maxSkills} skills from the list above that this candidate has clearly demonstrated. Aim for ${maxSkills} but return fewer if necessary.

STRICT REJECTION RULES — reject a skill if ANY of the following apply:
1. The skill description mentions a domain (ICT, technology, software, digital, clinical, medical, agricultural, marine, legal, scientific hypothesis-testing) that is NOT mentioned in the CV
2. The skill label contains a domain qualifier (e.g. "ICT", "Agile", "Lean", "scientific", "clinical") that does not appear in the CV text
3. The skill description describes activities the candidate has not performed, even if the label sounds relevant

SELECTION CRITERIA:
- The candidate's actual work experience, not just keyword overlap with the label
- Prefer broad, transferable skill labels over domain-specific variants
- "project management" is acceptable; "ICT project management" is not unless the CV mentions ICT

Return JSON: {"selected": ["uri1", "uri2", ...]} — only URIs from the list above, exactly as written.`;
}

export function buildPrompt(cvText: string, locale: CvLocale = 'en'): string {
  const valuesTaxonomy = VALUES_LIST.map(
    (label) => `- ${label}: ${VALUES_DICTIONARY[label].description}`,
  ).join('\n');

  if (locale === 'fr') {
    return `Tu analyses le CV d'une candidate ou d'un candidat. Effectue deux taches:

TACHE A - COMPETENCES NORMALISEES
Extrait 12 a 18 competences professionnelles distinctes du CV sous forme de capacites reutilisables et normalisees.
Pour chaque competence, attribue un score de "prominence" de 1 a 10 indiquant a quel point cette competence est centrale dans le parcours de la personne selon:
- Duree: plusieurs annees d'usage comptent plus qu'une seule mention
- Profondeur: un travail senior/lead compte plus qu'un usage accessoire d'un outil
- Recence: les roles recents comptent plus que les anciens
- Preuves: des accomplissements concrets (mesures, resultats) comptent plus qu'une simple mention

Regles:
- Chaque "phrase" doit etre une capacite reutilisable courte, idealement de 2 a 6 mots, sous forme nominale ou proche d'un intitule de competence.
- Bonnes sorties: "Team leadership", "Water resource management", "Frontend web application development".
- Mauvaises sorties: "Led a team in water management", "Responsible for managing water projects", "Worked with engineers on...".
- N'utilise PAS des phrases completes, des responsabilites de poste, des accomplissements entiers, ni des formulations commencant par des verbes comme lead/manage/worked/responsible.
- Regroupe les technologies tres proches dans une seule expression lorsqu'elles ont ete utilisees ensemble (par ex. "Analyse et visualisation de donnees avec Python et SQL" plutot que des expressions separees).
- N'extrais PAS un outil, une plateforme ou un framework mineur comme competence autonome s'il n'a ete utilise qu'accessoirement dans un role plus large. Integre-le plutot dans la capacite plus generale. Donne a un logiciel specifique sa propre expression uniquement si le travail principal de la personne etait fortement centre dessus.
- Couvre TOUS les domaines professionnels visibles dans le CV; ne laisse pas un seul domaine dominer la liste.
- Extrait uniquement des competences que la personne a reellement demontrees ou pratiquees. N'infere pas a partir du seul titre du poste ni d'une collaboration avec d'autres specialistes.
- Inclue a la fois des competences techniques (outils, technologies, methodes) et professionnelles (leadership, formation, conseil).
- Pour chaque competence, fournis aussi une "evidence" tres courte: une citation ou reformulation fidele du CV qui prouve explicitement cette competence.
- N'ajoute aucun domaine ou contexte qui n'est pas clairement soutenu par le texte du CV.
- Si le texte du CV semble degrade ou mal formate (par ex. artefacts d'OCR), fais de ton mieux pour l'interpreter.

TACHE B - VALEURS AU TRAVAIL
Deduis les 3 a ${MAX_VALUES} valeurs au travail les plus importantes a partir du CV.
Valeurs autorisees: utilise exactement les libelles canoniques anglais ci-dessous, en respectant la casse, meme si le CV est en francais:
${valuesTaxonomy}
- N'inclus une valeur que si le CV fournit des preuves concretes: domaines d'interet, choix, accomplissements.
- Trie de la PLUS importante a la MOINS importante selon la force des preuves.

CV:
"""
${truncateAtWord(cvText, MAX_TEXT_CHARS)}
"""

Retourne uniquement du JSON:
{
  "skills": [{"phrase": "...", "evidence": "...", "prominence": 8}, ...],
  "values": ["CanonicalEnglishValue1", ...]
}`;
  }

  return `You are analyzing a candidate's CV. Perform two tasks:

TASK A — NORMALIZED SKILLS
Extract 12 to 18 distinct professional skills from the CV as short, reusable, normalized capabilities.
For each skill, assign a "prominence" score from 1 to 10 reflecting how central that skill is to the candidate's career based on:
- Duration: years of sustained use outweighs a single mention
- Depth: senior/lead-level work outweighs incidental use of a tool
- Recency: recent roles matter more than old ones
- Evidence: concrete achievements (metrics, outcomes) outweigh bare mentions

Rules:
- Each "phrase" must be a short reusable capability, ideally 2 to 6 words, written like a skill label or noun phrase.
- Good outputs: "Team leadership", "Water resource management", "Frontend web application development".
- Bad outputs: "Led a team in water management", "Responsible for managing water projects", "Worked with engineers on...".
- Do NOT output full sentences, job responsibilities, complete achievements, or phrases starting with verbs like lead/manage/worked/responsible.
- Consolidate closely related technologies into one phrase when they were used together (e.g. "Data analysis and visualization using Python and SQL" rather than separate phrases for each).
- Do NOT extract a minor tool, platform, or framework as its own standalone skill phrase if it was only used incidentally within a larger role. Instead, fold it into the broader capability phrase. Only give a specific software tool its own phrase if the candidate's primary job was heavily centered on that tool.
- Cover ALL professional domains evident in the CV — do not let one domain dominate the list.
- Extract only skills the candidate has personally demonstrated or performed. Do not infer from job titles alone or from collaboration with specialists in other fields.
- Include both technical skills (tools, technologies, methodologies) and professional skills (leadership, training, consulting).
- For each skill, also provide a very short "evidence" quote or faithful paraphrase from the CV that explicitly supports the skill.
- Do not introduce any domain or context that is not clearly supported by the CV text.
- If the CV text appears damaged or poorly formatted (e.g. OCR artifacts), do your best to interpret it.

TASK B — WORK VALUES
Infer the candidate's 3 to ${MAX_VALUES} most important work values from the CV.
Allowed values (use exact spelling, case-sensitive):
${valuesTaxonomy}
- Only include a value when the CV gives concrete evidence — focus areas, choices, achievements.
- Order from MOST to LEAST important based on evidence strength.

CV:
"""
${truncateAtWord(cvText, MAX_TEXT_CHARS)}
"""

Return JSON:
{
  "skills": [{"phrase": "...", "evidence": "...", "prominence": 8}, ...],
  "values": ["Value1", ...]
}`;
}
